from django.contrib import admin

from .models import * 

admin.site.register(Saldo)
admin.site.register(Pogasheniya)
admin.site.register(Likvidnost)
admin.site.register(Kapital)

