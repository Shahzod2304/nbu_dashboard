from django.urls import path 
from .views import * 


urlpatterns = [
    path('home', Dashboard, name="dashboard"),
    path('icons/', Icons, name="icons"),
    path('map/', Map, name="map"),
    path('upload/', Upload, name="upload"),
    path('profile/', Pogasheniya_view, name="profile"),
    path('sign-in/', Sign_in, name="sign_in"),
    path('sign-up/', Sign_up, name="sign_up"),
    path('tables/', Tables, name="tables"),
    path('template/', Template, name="template"),
    path('typography/', Typography, name="typography"),
    path('upload2/', Upload_Pogasheniya, name="upload2"),
    path('upload_perecent/', Upload_Perecent, name="upload_perecent"),
    path('upload_aktiv/', Upload_Aktiv, name = 'upload_aktiv'),
    path('upload_korrschet/', Upload_Korrschet, name = 'upload_korrschet'),
    path('login/', Login, name="login"),
    path('', custom_logout, name='logout'),
    path('korrschet/', Korrschet, name='korrschet'),
    path('dynamik-aktiv-passiv/', Dynamik_aktiv_passiv, name='dynamik_aktiv_passiv'),
    path('dynamik-aktiv-passiv-table/', Dynamik_table, name='dynamik_table'),
    path('korrschet-detail/', Korrschet_Detail, name="korrschet_detail"),
    path('chart-doxod/', Chart_Doxod, name='chart_doxod'),
    path('autocomplete/', autocomplete_view, name='autocomplete'),
    path('info-otchot/', Info_Otchot, name='info-otchot'),

    # path('upload-dynamik/', Upload_Dynamik, name='upload_dynamik'),
    
]

