from django.db import models

# Create your models here.
class Perecent(models.Model):
    LOAN_ID = models.CharField(max_length=15, blank=True, null=True, db_index=True) 
    PERC_CODE_DESC = models.CharField(max_length=4, null=True, blank=True)
    PERC_TYPE = models.CharField(max_length=10, null=True, blank=True, db_index=True)
    TOTAL_RATE = models.FloatField(null=True, blank=True, db_index=True)

class Saldo(models.Model):
    OPER_DAY = models.DateField(db_index=True, blank=True, null=True)
    LOAN_ID = models.CharField(max_length=15, blank=True, null=True) 
    CODE_FILIAL = models.CharField(max_length=5, blank=True, null=True)
    ACCOUNT_CODE2 = models.CharField(max_length=64, blank=True, null=True, db_index=True)
    SALDO_IN = models.BigIntegerField(blank=True, null=True, db_index=True)
    SALDO_OUT = models.BigIntegerField(blank=True, null=True, db_index=True)
    SALDO_EQUIVAL_IN = models.BigIntegerField(blank=True, null=True, db_index=True)
    DATE_FROM = models.DateField(db_index=True, blank=True, null=True)
    DATE_TO = models.DateField(db_index=True, blank=True, null=True)
    SALDO_EQUIVAL_OUT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_DEBIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_CREDIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_ALL_DEBIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_ALL_CREDIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    CODE_CURRENCY = models.CharField(max_length=3, blank=True, null=True, db_index=True)
    LOAN_TYPE_ACCOUNT = models.CharField(max_length=10, blank=True, null=True, db_index=True)
    CLIENT_NAME = models.CharField(max_length=255, blank=True, null=True)
    SOURCE_CRED = models.CharField(max_length=5, blank=True, null=True, db_index=True)
    SUBJECT = models.CharField(max_length=5, blank=True, null=True, db_index=True)
    TOTAL_RATE = models.FloatField(blank=True, null=True)

    class Meta:
        indexes = [
            models.Index(fields=['OPER_DAY', 'ACCOUNT_CODE2', 'SALDO_EQUIVAL_OUT', 'CODE_CURRENCY', 'SOURCE_CRED', 'SUBJECT', 'DATE_FROM', 'DATE_TO']),     
        ]
    
    def __str__(self):
        return str(self.OPER_DAY)

class Aktiv_Saldo(models.Model):
    OPER_DAY = models.DateField(db_index=True, blank=True, null=True)
    CODE_FILIAL = models.CharField(max_length=5, blank=True, null=True)
    ACCOUNT_CODE2 = models.CharField(max_length=64, blank=True, null=True, db_index=True)
    SALDO_IN = models.BigIntegerField(blank=True, null=True, db_index=True)
    SALDO_OUT = models.BigIntegerField(blank=True, null=True, db_index=True)
    SALDO_EQUIVAL_IN = models.BigIntegerField(blank=True, null=True, db_index=True)
    DATE_FROM = models.DateField(db_index=True, blank=True, null=True)
    DATE_TO = models.DateField(db_index=True, blank=True, null=True)
    SALDO_EQUIVAL_OUT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_DEBIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_CREDIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_ALL_DEBIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_ALL_CREDIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    CODE_CURRENCY = models.CharField(max_length=3, blank=True, null=True, db_index=True)
    class Meta:
        indexes = [
            models.Index(fields=['OPER_DAY', 'ACCOUNT_CODE2', 'SALDO_EQUIVAL_OUT', 'CODE_CURRENCY', 'DATE_FROM', 'DATE_TO']),
        ]
    
    def __str__(self):
        return str(self.OPER_DAY)
    
class Depozit_Yurik(models.Model):
    OPER_DAY = models.DateField(db_index=True, blank=True, null=True)
    CODE_FILIAL = models.CharField(max_length=5, blank=True, null=True)
    ACCOUNT_CODE2 = models.CharField(max_length=64, blank=True, null=True, db_index=True)
    SALDO_IN = models.BigIntegerField(blank=True, null=True, db_index=True)
    SALDO_OUT = models.BigIntegerField(blank=True, null=True, db_index=True)
    SALDO_EQUIVAL_IN = models.BigIntegerField(blank=True, null=True, db_index=True)
    DATE_FROM = models.DateField(db_index=True, blank=True, null=True)
    DATE_TO = models.DateField(db_index=True, blank=True, null=True)
    SALDO_EQUIVAL_OUT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_DEBIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_CREDIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_ALL_DEBIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_ALL_CREDIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    CODE_CURRENCY = models.CharField(max_length=3, blank=True, null=True, db_index=True)
    CONTRACT_ID = models.CharField(max_length=15, blank=True, null=True) 
    CODE = models.CharField(max_length=15, blank=True, null=True)
    DATE_ACTIVE = models.DateField(db_index=True, blank=True, null=True)
    RATE = models.FloatField(blank=True, null=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['OPER_DAY', 'ACCOUNT_CODE2', 'SALDO_EQUIVAL_OUT', 'CODE_CURRENCY', 'DATE_FROM', 'DATE_TO']),
        ]
    
    def __str__(self):
        return str(self.OPER_DAY)
    
class Pogasheniya(models.Model):
    OPER_DAY = models.DateField(db_index=True, blank=True, null=True)
    ACCOUNT_CO = models.CharField(max_length=64, blank=True, null=True, db_index=True)
    DEBIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    CREDIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    ACCOUNT_CODE = models.CharField(max_length=64, blank=True, null=True, db_index=True)
    DOC_NUMB = models.CharField(max_length=15, blank=True, null=True)
    DOCUMENT_CODE = models.CharField(max_length=15, blank=True, null=True)
    CURRENCY_CODE = models.CharField(max_length=23, blank=True, null=True, db_index=True)
    NAME = models.CharField(max_length=255, blank=True, null=True)
    LEAD_ID = models.CharField(max_length=15, blank=True, null=True)
    LOAN_ID = models.CharField(max_length=15, blank=True, null=True, db_index=True) 
    SALDO_EQUIVAL_OUT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TOTAL_SUMM_RED = models.BigIntegerField(blank=True, null=True, db_index=True)

    def __str__(self):
        return str(self.OPER_DAY)
    
class Korrschet_Data(models.Model):
    ID = models.CharField(max_length=64, db_index=True, blank=True, null=True)
    OPER_DAY = models.DateField(db_index=True, blank=True, null=True)
    ACCOUNT_CODE2 = models.CharField(max_length=64, db_index=True, blank=True, null=True)
    COA_CODE = models.CharField(max_length=6, db_index=True, blank=True, null=True)
    COA_3 = models.CharField(max_length=4, db_index=True, blank=True, null=True)
    SALDO_IN = models.BigIntegerField(blank=True, null=True, db_index=True)
    SALDO_OUT = models.BigIntegerField(blank=True, null=True, db_index=True)
    SALDO_EQUIVAL_IN =models.BigIntegerField(blank=True, null=True, db_index=True)
    SALDO_EQUIVAL_OUT = models.BigIntegerField(blank=True, null=True, db_index=True)
    SALDO_EQ_USD_IN = models.BigIntegerField(blank=True, null=True, db_index=True)
    SALDO_EQ_USD_OUT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_DEBIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_CREDIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_ALL_DEBIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_ALL_CREDIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    CODE_CURRENCY = models.CharField(max_length=3, blank=True, null=True, db_index=True)
    NAME = models.CharField(max_length=255, blank=True, null=True, db_index=True)

    class Meta:
        indexes = [
            models.Index(fields=['OPER_DAY', 'ACCOUNT_CODE2', 'COA_CODE', 'COA_3', 'SALDO_EQUIVAL_OUT', 'CODE_CURRENCY', 'NAME']),
        ]
    def __str__(self):
        return str(self.OPER_DAY)
    
class Chart_Data(models.Model):
    OPER_DAY = models.DateField(db_index=True, blank=True, null=True)
    COA_CODE = models.CharField(max_length=6, db_index=True, blank=True, null=True)
    COA_3 = models.CharField(max_length=4, db_index=True, blank=True, null=True)
    SALDO_EQUIVAL_OUT_SUM = models.BigIntegerField(blank=True, null=True, db_index=True)
    SALDO_OUT_SUM = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_DEBIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_CREDIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    SALDO_IN = models.BigIntegerField(blank=True, null=True, db_index=True)
    CODE_CURRENCY = models.CharField(max_length=3, blank=True, null=True, db_index=True)
    SALDO_EQUIVAL_IN = models.BigIntegerField(blank=True, null=True, db_index=True)
    DATE_FROM = models.DateField(db_index=True, blank=True, null=True)
    DATE_TO = models.DateField(db_index=True, blank=True, null=True)

    class Meta:
        indexes = [
            models.Index(fields=['OPER_DAY', 'COA_CODE', 'COA_3', 'CODE_CURRENCY', 'DATE_FROM','DATE_TO']),
        ]
    def __str__(self):
        return str(self.OPER_DAY)

class Saldo_Pogasheniya(models.Model):
    OPER_DAY = models.DateField(db_index=True, blank=True, null=True)
    ACCOUNT_CODE = models.CharField(max_length=64, db_index=True, blank=True, null=True)
    COA_CODE = models.CharField(max_length=6, db_index=True, blank=True, null=True)
    SALDO_EQUVAL_OUT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_DEBIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_CREDIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    LOAN_ID = models.CharField(max_length=15, blank=True, null=True, db_index=True) 
    ACCOUNT_NAME = models.CharField(max_length=255, blank=True, null=True, db_index=True)
    SUMM_RED_SUM = models.BigIntegerField(blank=True, null=True, db_index=True)


class Dwh_account(models.Model):
    OPER_DAY = models.DateField(db_index=True, blank=True, null=True)
    ACCOUNT_CODE = models.CharField(max_length=64, db_index=True, blank=True, null=True)
    ACCOUNT_CO = models.CharField(max_length=64, db_index=True, blank=True, null=True)
    DEBIT =  models.BigIntegerField(blank=True, null=True, db_index=True)
    CREDIT =  models.BigIntegerField(blank=True, null=True, db_index=True)
    CURRENCY_CODE = models.CharField(max_length=3, blank=True, null=True, db_index=True)


class Pogasheniya_new(models.Model):
    COA_CODE = models.CharField(max_length=255)
    LOAN_ID = models.CharField(max_length=255)
    OPER_DAY = models.DateField()
    SALDO_EQUVAL_OUT = models.DecimalField(max_digits=20, decimal_places=2)
    SUMM_RED_SUM = models.DecimalField(max_digits=20, decimal_places=2)
    ACCOUNT_NAME = models.CharField(max_length=255)
    ACCOUNT_CODE = models.CharField(max_length=255)
    ACCOUNT_CO = models.CharField(max_length=255)
    total_credit = models.DecimalField(max_digits=20, decimal_places=2)
    total_debit = models.DecimalField(max_digits=20, decimal_places=2)

class Big_Data_Saldo(models.Model):
    DATE_FROM = models.DateField(db_index=True, blank=True, null=True)
    DATE_TO = models.DateField(db_index=True, blank=True, null=True)
    COA_CODE = models.CharField(max_length=64, db_index=True, blank=True, null=True)
    COA_3 = models.CharField(max_length=4, db_index=True, blank=True, null=True)
    SALDO_EQUIVAL_OUT_SUM = models.BigIntegerField(blank=True, null=True, db_index=True)
    CODE_CURRENCY = models.CharField(max_length=3, blank=True, null=True, db_index=True)
    SALDO_OUT_SUM = models.BigIntegerField(blank=True, null=True, db_index=True)


    class Meta:
        indexes = [
            models.Index(fields=['COA_CODE', 'COA_3', 'CODE_CURRENCY', 'DATE_FROM','DATE_TO']),
        ]
    def __str__(self):
        return str(self.COA_3)


class Likvidnost(models.Model):
    LIKVIDNOST_CHOICES = [
        ("Норма стабильного финансирования (NSFR)", "Норма стабильного финансирования (NSFR)"),
        ("Коэффициент покрытия ликвидности (LCR)", "Коэффициент покрытия ликвидности (LCR)"),
        ("Доля ВЛА в совокупных активах", "Доля ВЛА в совокупных активах"),
    ]

    likvidnost_name = models.CharField(max_length=255, choices=LIKVIDNOST_CHOICES)
    fakt = models.CharField(max_length=255)
    nats_valuta = models.CharField(max_length=255)
    ino_valuta = models.CharField(max_length=255)
    date = models.DateField()

    def __str__(self):
        return str(self.likvidnost_name)

class Kapital(models.Model):
    KAPITAL_CHOICES = [
        ("Коэффициент достаточности капитала I уровня", "Коэффициент достаточности капитала I уровня"),
        ("Левераж", "Левераж"),
        ("Коэффициент достаточности капитала", "Коэффициент достаточности капитала"),
    ]

    kapital_dostatochna_name = models.CharField(max_length=255, choices=KAPITAL_CHOICES)
    normativ_sb = models.CharField(max_length=255)
    fakt = models.CharField(max_length=255)
    date = models.DateField()

    def __str__(self):
        return str(self.kapital_dostatochna_name)

class Korrschet_big_data(models.Model):
    OPER_DAY = models.DateField(db_index=True, blank=True, null=True)
    COA_CODE = models.CharField(max_length=64, db_index=True, blank=True, null=True)
    COA_3 = models.CharField(max_length=4, db_index=True, blank=True, null=True)
    SALDO_EQUIVAL_OUT_SUM = models.BigIntegerField(blank=True, null=True, db_index=True)
    SALDO_OUT_SUM = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_DEBIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    TURNOVER_CREDIT = models.BigIntegerField(blank=True, null=True, db_index=True)
    SALDO_IN = models.BigIntegerField(blank=True, null=True, db_index=True)
    CODE_CURRENCY = models.CharField(max_length=15, blank=True, null=True, db_index=True)
    SALDO_EQUIVAL_IN = models.BigIntegerField(blank=True, null=True, db_index=True)

class Depozit_Yuridik(models.Model):
    ACCOUNT_CODE = models.CharField(max_length=64, db_index=True, blank=True, null=True)
    CONTRACT_ID = models.CharField(max_length=64, db_index=True, blank=True, null=True)
    PERCENT_TYPE = models.CharField(max_length=64, db_index=True, blank=True, null=True)
    DATE_VALIDATE = models.DateField(db_index=True, blank=True, null=True)
    PERCENT_RATE = models.DecimalField(max_digits=30, decimal_places=2, blank=True, null=True)
    EMP_CODE = models.CharField(max_length=64, blank=True, null=True)
    DATE_MODIFY = models.DateTimeField(db_index=True, blank=True, null=True)
    LIBOR = models.CharField(max_length=25, blank=True, null=True)
    CODE = models.CharField(max_length=64, blank=True, null=True)
    DATE_ACTIVE = models.DateField(blank=True, null=True)
    DATE_DEACTIVE = models.DateField(blank=True, null=True)
    SALDO_EQUIVAL_OUT = models.BigIntegerField(blank=True, null=True, db_index=True)
    RATE = models.DecimalField(max_digits=30, decimal_places=2, blank=True, null=True)
    TOTAL_RATE = models.DecimalField(max_digits=30, decimal_places=2, blank=True, null=True)
    TOTAL_PLATEJ = models.DecimalField(max_digits=30, decimal_places=2, blank=True, null=True)
    NAME = models.CharField(max_length=255, blank=True, null=True)
    SALDO_OUT = models.BigIntegerField(blank=True, null=True, db_index=True)
    CODE_CURRENCY = models.CharField(max_length=15, blank=True, null=True, db_index=True)
    CODE_CLIENT = models.CharField(max_length=64, db_index=True, blank=True, null=True)


class Payment(models.Model):
    code_client = models.CharField(max_length=250, blank=True, null=True)
    operden = models.DateField( blank=True, null=True)
    document_number = models.CharField(max_length=250, blank=True, null=True)
    document_date = models.DateField( blank=True, null=True)
    payer_mfo = models.CharField(max_length=250, blank=True, null=True)
    payer_account = models.CharField(max_length=250, blank=True, null=True)
    payer_inn = models.CharField(max_length=250, blank=True, null=True)
    payer_name = models.CharField(max_length=255, blank=True, null=True)
    receiver_mfo = models.CharField(max_length=250, blank=True, null=True)
    receiver_account = models.CharField(max_length=250, blank=True, null=True)
    receiver_inn = models.CharField(max_length=250, blank=True, null=True)
    receiver_name = models.CharField(max_length=255, blank=True, null=True)
    payment_description = models.TextField( blank=True, null=True)
    document_amount = models.DecimalField(max_digits=220, decimal_places=2, blank=True, null=True)
    document_type = models.CharField(max_length=250, blank=True, null=True)
    status = models.CharField(max_length=250, blank=True, null=True)
    route = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    created_by = models.CharField(max_length=250, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, blank=True, null=True)
    incoming_file_id = models.CharField(max_length=250, null=True, blank=True)
    outgoing_file_id = models.CharField(max_length=250, null=True, blank=True)
    incoming_files = models.TextField(null=True, blank=True)
    outgoing_files = models.TextField(null=True, blank=True)

    class Meta:
        db_table = 'payments'
        verbose_name = 'Payment'
        verbose_name_plural = 'Payments'

    def __str__(self):
        return f'{self.document_number} - {self.payer_name} to {self.receiver_name}'





