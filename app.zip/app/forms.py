# forms.py
from django import forms

class UploadFileForm(forms.Form):
    file = forms.FileField()

class UploadPogasheniyaForm(forms.Form):
    file = forms.FileField()

class Upload_Perecent_Form(forms.Form):
    file = forms.FileField()
    
class Upload_Aktiv_Form(forms.Form):
    file = forms.FileField()    

class Upload_Korrschet_Form(forms.Form):
    file = forms.FileField() 


class Upload_Dynamik_Form(forms.Form):
    file = forms.FileField()

class LoginForm(forms.Form):
    username = forms.CharField(label='Username')
    password = forms.CharField(label='Password', widget=forms.PasswordInput)

